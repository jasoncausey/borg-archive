# borg-archive

A Python tool for creating single-file compressed archives using [Borg Backup](https://www.borgbackup.org/).

**WARNING:** This tool is still in an early state. Please consider it "alpha" quality software at this point and always keep a backup of your data using another means in addition to `borg-archive`.

This tool allows you to create, extract, mount, and update Borg archives that are stored as single compressed files. It's particularly useful for sharing and archiving versioned datasets for research purposes.

## Features

- Create single-file compressed archives using Borg Backup
- Extract archives to a directory
- Mount archives read-only (requires FUSE)
- Update archives with new changes
- List available versions/tags in an archive
- Automatic compression using zstd
- Modern CLI with rich terminal output

## Requirements

- Python 3.12 or later
- [Borg Backup](https://www.borgbackup.org/)
- [SquashFS](https://github.com/plougher/squashfs-tools) (optional, but recommended)
    - `tar` (usually pre-installed) if SquashFS is not installed.
- `zstd`, `gzip` (`pigz` is optional but recommended if `tar` is used)
- FUSE (optional, required for mount functionality)
  - For macOS: [macFuse](https://macfuse.github.io/)

## Installation

You can install `borg-archive` using pip:

```bash
pip install borg-archive
```

Or for a more isolated installation, use [pipx](https://pypa.github.io/pipx/):

```bash
pipx install borg-archive
```

Or, you can use `uv tool` to install:

```bash
uv tool install borg-archive
```

## Usage

### Create a New Archive

```bash
borg-archive create archive.baz /path/to/data
```

### Extract an Archive

Latest version:
```bash
borg-archive extract archive.baz /path/to/output
```

Specific version:
```bash
borg-archive extract archive.baz /path/to/output --tag selected-tag
```

### List Available Tags

```bash
borg-archive list archive.baz
```

### Mount an Archive (Read-only)

```bash
borg-archive mount archive.baz /path/to/mount
```

### Unmount an Archive

```bash
borg-archive umount /path/to/mount
```

### Update an Archive

```bash
borg-archive update archive.baz /path/to/data
```

With a specific tag:
```bash
borg-archive update archive.baz /path/to/data --tag custom-tag
```

## Python API

You can also use borg-archive as a Python library:

```python
from pathlib import Path
from borg_archive import BorgArchive

# Create a new archive
with BorgArchive(Path("archive.baz")) as archive:
    archive.create(Path("/path/to/data"))

# Extract an archive
with BorgArchive(Path("archive.baz")) as archive:
    archive.extract(Path("/path/to/output"))

# List tags
with BorgArchive(Path("archive.baz")) as archive:
    archive.list_tags()

# Mount an archive
with BorgArchive(Path("archive.baz")) as archive:
    archive.mount(Path("/path/to/mount"))

# Update an archive
with BorgArchive(Path("archive.baz")) as archive:
    archive.update(Path("/path/to/data"))
```

## License

MIT License - see LICENSE.md for details.

## Acknowledgments

This project was inspired by the need for a better way to store and share versioned datasets, and builds upon the excellent [Borg Backup](https://www.borgbackup.org/) tool.
